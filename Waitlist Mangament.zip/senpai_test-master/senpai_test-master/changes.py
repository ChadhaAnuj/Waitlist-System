
import csv
import pymysql, xlrd, os
import urllib.request
url = 'https://storage.googleapis.com/csc330fa19/schedule.xlsx'
urllib.request.urlretrieve(url,'Schedule_071819.xlsx')
wb = xlrd.open_workbook('Schedule_071819.xlsx')
sheet = wb.sheet_by_index(0)
for i in range(sheet.nrows):
    print(sheet.row_values(i))
