# senpai_test

Administrator username: admin
Administrator password: control

Regular username: rosst
Regular password: test123

Excel spreadsheet for updating is being hosted by timryanross@gmail.com at https://docs.google.com/spreadsheets/d/1rAnb2fzjpapSPKePSe2SWYPxZsIFDhrv/export?format=xlsx

The spreadsheet above can be edited by you for testing our application

Duplicate sections have been removed, and a class that had different lecture enrollment, and lab enrollment now has the same enrollment

Updating the CSV data must be done manually by visiting http://34.73.248.174:8080/changes

Address: http://34.73.248.174:8080/
